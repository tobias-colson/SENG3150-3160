---------------------------------------------------------------
---------------------------------------------------------------
----------------SENG3160 - Group4------------------------------
FlightPub Implementation
---------------------------------------------------------------
---------------------------------------------------------------

---------------------------------------------------------------
----------------Database Setup:--------------------------------
Run seng3150_group4.sql against a new database seng3150_group4
with the following credentials: username=root, password=root
---------------------------------------------------------------

---------------------------------------------------------------
----------------Project Setup:---------------------------------
I wasn't sure how much detail you required to get it set up in
IntelliJ, so I have provided as much as I can.

-----This project was built using Maven-----
Primary Frameworks:
* Spring MVC
* JPA2 with Hibernate

The project was created and run through Intellij Ultimate,
extract the zip file and Open an Intellij project from this
source.
Import Maven dependencies and set up Tomcat server by accessing:
Run->Edit Configurations...
With a tomcat local server selected, select "Fix" in the bottom
right to build the .war and run the server.
---------------------------------------------------------------
---------------------------------------------------------------
---------------------------------------------------------------