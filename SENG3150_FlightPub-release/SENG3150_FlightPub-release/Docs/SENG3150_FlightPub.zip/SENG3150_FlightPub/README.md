# SENG3150_FlightPub
Paypal instructions: When prompted for an account email: flightpubtest@gmail.com password: flightpub123