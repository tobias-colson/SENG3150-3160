package seng3150.group4;

/*
 * Created By: Benjamin Collins
 * Data Last Modified: 7/09/2018
 * Purpose: Contains all controller methods for user management including
 *      * login
 *      * register
 *      * logout
 *      * flight history
 *      * change details
 */

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import seng3150.group4.entity.FlightHistoryEntity;
import seng3150.group4.entity.UserEntity;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@Controller
public class UserManagementController {

    private static EntityManager em = null;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login()
    {
        return "Login";
    }

    @RequestMapping(value = "/login/authenticate", method = RequestMethod.POST)
    public String authenticate(HttpServletRequest request, ModelMap model)
    {
        if (em == null)
        {
            em = (EntityManager) Persistence.createEntityManagerFactory("FlightPubPU").
                    createEntityManager();
        }

        Query query =  em.createQuery("SELECT u FROM UserEntity u WHERE u.username=:username");
        query.setParameter("username", request.getParameter("username"));
        try
        {
            UserEntity existingUser = (UserEntity) query.getSingleResult();
            String hashedPassword = hashPassword(request.getParameter("password"));
            if (hashedPassword.equals(existingUser.getPasswordHash()))
            { // successful login
                request.getSession().setAttribute("user", existingUser);
                return "Search";
            }
            else
            {
                model.put("error", "The password you have entered is incorrect.");
            }
        }
        catch (NoResultException e)
        { // Username does not exist
            model.put("error", "There is no account under that username.");
        }
        return "Login";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpSession session)
    {
        session.removeAttribute("user");
        return "Login";
    }

    @RequestMapping(value = "/account", method = RequestMethod.GET)
    public String account()
    {
        return "Account";
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String register()
    {
        return "Register";
    }

    @RequestMapping(value = "/register/confirm", method = RequestMethod.POST)
    public String registerConfirm(HttpServletRequest request, ModelMap model)
    {
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        if (!password.equals(password2))
        {
            // user has not typed the same password twice
            model.put("error", "The passwords entered do not match.");
            return "Register";
        }
        // save new user's details and return them to login screen
        if (em == null)
        {
            em = (EntityManager) Persistence.createEntityManagerFactory("FlightPubPU").
                    createEntityManager();
        }

        Query query =  em.createQuery("SELECT username, email FROM UserEntity WHERE username=:username OR email=:email");
        query.setParameter("username", request.getParameter("username"));
        query.setParameter("email", request.getParameter("email"));
        List<UserEntity> existingUser = query.getResultList();

        if (existingUser.size() > 0)
        { // user with that username or email already exists
            model.put("error", "That username and/or email has already been taken.");
            return "Register";
        }

        String hashedPassword = hashPassword(request.getParameter("password"));

        em.getTransaction().begin();
        // Create new user
        UserEntity newUser = new UserEntity();
        newUser.setUsername(request.getParameter("username"));
        newUser.setTitle(request.getParameter("title"));
        newUser.setFirstName(request.getParameter("firstname"));
        newUser.setLastName(request.getParameter("lastname"));
        newUser.setPhoneNumber(request.getParameter("phonenum"));
        newUser.setDOB(request.getParameter("dob"));
        newUser.setEmail(request.getParameter("email"));
        newUser.setPasswordHash(hashedPassword);

        em.persist(newUser);
        em.getTransaction().commit();

        return "Login";
    }

    @RequestMapping(value = "/changedetails", method = RequestMethod.POST)
    public String changeDetails(HttpServletRequest request, ModelMap model)
    {
        return "ChangeDetails";
    }

    @RequestMapping(value = "/changedetails/confirm", method = RequestMethod.POST)
    public String changeDetailsConfirm(HttpServletRequest request, ModelMap model) {
        UserEntity currentUser = (UserEntity) request.getSession().getAttribute("user");

        String password = (request.getParameter("password").equals("")) ? "" : request.getParameter("password");
        String password2 = (request.getParameter("password2").equals("")) ? "" : request.getParameter("password2");

        if (!password.equals("") && !password2.equals(""))
        {
            if (!password.equals(password2))
            {
                // user has not typed the same password twice
                model.put("error", "The passwords entered do not match.");
                return "Account";
            }
        }
        // XOR: if one is empty and the other is not empty
        if ((password.equals("") || password2.equals("")) && !(password.equals("") && password2.equals("")))
        {
            model.put("error", "You must enter the password in both fields.");
            return "Account";
        }

        // save new user's details and return them to login screen
        if (em == null)
        {
            em = (EntityManager) Persistence.createEntityManagerFactory("FlightPubPU").
                    createEntityManager();
        }

        String hashedPassword = (password.equals("") && password2.equals("")) ? currentUser.getPasswordHash()
                : hashPassword(request.getParameter("password"));

        em.getTransaction().begin();
        // Create new user
        if (!(request.getParameter("title").equals(""))) currentUser.setTitle(request.getParameter("title"));
        if (!(request.getParameter("firstname").equals(""))) currentUser.setFirstName(request.getParameter("firstname"));
        if (!(request.getParameter("lastname").equals(""))) currentUser.setLastName(request.getParameter("lastname"));
        if (!(request.getParameter("phonenum").equals(""))) currentUser.setPhoneNumber(request.getParameter("phonenum"));
        if (!(request.getParameter("dob").equals(""))) currentUser.setDOB(request.getParameter("dob"));
        if (!(request.getParameter("email").equals(""))) currentUser.setEmail(request.getParameter("email"));
        if (!(request.getParameter("password").equals(""))) currentUser.setPasswordHash(hashedPassword);

        em.persist(currentUser);
        em.getTransaction().commit();

        return "Account";
    }

    @RequestMapping(value = "/account/flighthistory", method = RequestMethod.GET)
    public String flightHistory(HttpSession session, ModelMap model) {
        if (em == null)
        {
            em = (EntityManager) Persistence.createEntityManagerFactory("FlightPubPU").
                    createEntityManager();
        }

        UserEntity currentUser = (UserEntity) session.getAttribute("user");
        int userID = currentUser.getId();

        Query historyQuery = em.createQuery("SELECT f FROM FlightHistoryEntity f WHERE f.id.userID=:userId");
        historyQuery.setParameter("userId", userID);
        List<FlightHistoryEntity> flights = historyQuery.getResultList();

        model.put("flights", flights);

        return "FlightHistory";
    }

    // Returns the hashed variation of the user's password for storage
    private String hashPassword(String password) {
        String hashedPassword = null;
        try
        {
            MessageDigest mD = MessageDigest.getInstance("MD5");
            mD.update(password.getBytes());
            byte[] pBytes = mD.digest();
            StringBuilder sB = new StringBuilder();
            for (byte pByte : pBytes)
            {
                sB.append(Integer.toString((pByte & 0xff) + 0x100, 16).substring(1));
            }
            hashedPassword = sB.toString();
        }
        catch (NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        return hashedPassword;
    }
}
